@extends('templates.main')
@section('content')

 @auth
    <div class="top-container dark-background">
        <h2> {{$titulo}} </h2>
        <table class="table">
            <thead>
                <tr class="bg-primary">
                    <th scope="col">Curso</th>
                    <th scope="col">Carga Horaria</th>
                    <th scope="col">Descripción</th>
                    <th scope="col">Docente</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($cursos as $item)
                    @if($item)
                        <tr class="table-primary">
                            <td><a href="{{$item->nombre}}">{{$item->nombre}}</a></td>
                            <td>{{$item->carga_horaria}}</td>
                            <td>{{$item->descripcion}}</td>
                            <td>{{$item->docente}}</td>
                            
                        </tr>
                    @endif
                @endforeach
                </tr>
            </tbody>
        </table>
    </div>
@endauth

@endsection
