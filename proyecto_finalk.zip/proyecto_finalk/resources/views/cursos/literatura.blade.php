@extends('templates.main')
@section('content')
    <div class=container>
        <header>
            <div class="container p-3" >
                <div class="row">
                    <div class="col">
                        <h1>Literatura</h1>
                        <p>Incribiendote al curso de Literatura, vas a tenes acceso a mas de 50000 libros brindados por nuestra organizacion, cuando lo desees</p>
                        <p>Si el material deseado no se encuentra a disponicion, se pondra en atencio el stock en 24hs</p>
                    </div>
                </div>
            </div>
        </header>
        <div class="container">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="./img/lit/l1.jpg" class="img-fluid" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <p class="remarca">Incribete a las clases de literatura 20% off</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="./img/lit/l2.jpg" class="img-fluid" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <p class="remarca">Puede elegir donde y cuando quieras relizar el curso</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="./img/lit/l3.jpg" class="img-fluid" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <p class="remarca">Profesores activos 24/7 para cuando lo necesites</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="./img/1_1.jpg" class="img-fluid" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <p class="remarca">Acceso a materiales cuando tu quieras!</p>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
                </a>
            </div>
        </div>

        <div class="container">
            <div class="container p-3" >
                <div class="row">
                    <div class="col">
                        <p> Las humanidades expresan la experiencia humana a través de varias disciplinas, entre ellas: Historia, Filosofía, Gestión ambiental, Arte, Deporte y Literatura. 
    
                            Ésta área busca aportar herramientas al educando que le permitan desarrollar habilidades para desenvolverse con un sentido más crítico y analítico en su desempeño profesional y personal, desarrollando competencias en todos los ámbitos a través de las experiencias y aprendizajes vividos durante los cursos.
                        
                            Su principal fin es sensibilizar al estudiante y lograr que desarrolle todas las funciones humanas de manera integral, abordando no sólo la parte técnica y cognitiva, sino también la ética, afectiva, espiritual y social.
                        
                            Por tal motivo, el curso de Literatura nos va a llevar a conocer obras literarias de diferentes escritores, abarcaremos distintas generaciones literarias y recorreremos juntos la historia de la literatura  en las obras de los principales exponentes de la literatura universal.
                        
                            Juntos aprenderemos a contextualizar la ideología de una época determinada y a emplear nuestras vivencias y conocimientos en el rescate de nuestros valores y costumbres. Juntos encontraremos más razones por las cuales leer. </p>
                    </div>
                </div>
            </div>
            
        </div>
        @auth
            <form action="{{ route('inscriptos.store') }}" method="POST">
                @csrf
                 <input type="hidden" id="nombre_curso" name="nombre_curso" value="literatura">
                <button type="submit" class="btn btn-primary">Sumate al curso</button>
            </form>
        @endauth
        @guest
                <a href="{{route('login')}}" class="btn btn-primary"> Tenes que que estar logueado para sumarte al curso</a>
        @endguest
    </div>
@endsection