@extends('templates.main')
@section('content')
    <div class=container>
        <header>
            <div class="container p-3" >
                <div class="row">
                    <div class="col">
                        <h1>Ingles</h1>
                        <p>Incribiendote al curso de Ingles, vas a tenes acceso a mas de Videos brindados por nuestra organizacion, cuando lo desees</p>

                    </div>
                </div>
            </div>
        </header>
        <div class="container">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="./img/ing/i1.png" class="img-fluid" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <p class="remarca">Incribete a las clases de literatura 20% off</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="./img/ing/i2.png" class="img-fluid" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <p class="remarca">Puede elegir donde y cuando quieras relizar el curso</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="./img/4.jpg" class="img-fluid" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <p class="remarca">Profesores activos 24/7 para cuando lo necesites</p>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
        @auth
            <form action="{{ route('inscriptos.store') }}" method="POST">
                @csrf
                 <input type="hidden" id="nombre_curso" name="nombre_curso" value="ingles">
                <button type="submit" class="btn btn-primary">Sumate al curso</button>
            </form>
        @endauth
        @guest
                <a href="{{route('login')}}" class="btn btn-primary"> Tenes que que estar logueado para sumarte al curso</a>
        @endguest
    </div>
@endsection