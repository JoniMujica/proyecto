@extends('templates.main')
@section('content')
    @auth
        <div class="container tpt">
            <table class="table">
                <thead>
                    <tr class="bg-primary">
                        <th scope="col">Curso</th>
                        <th scope="col">Descripción</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($inscripciones as $item)
                        @if($item)
                            <tr class="table-primary">
                                <td>{{$item->nombre}}</td>
                                <td>{{$item->descripcion}}</td>
                                
                            </tr>
                        @endif
                    @endforeach
                    </tr>
                </tbody>
            </table>
        </div>
    @endauth
    @guest
        <div class="container">
            Debes iniciar sesion para poder ver esta pagina
        </div>
     @endguest
@endsection