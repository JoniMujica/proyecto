@extends('templates.main')
    @section('content')
    <div class="container">
        <h2> Bienvenidos </h2>
        <p> Nuestros datos</p>
    </div>
    @endsection

