@extends('templates.main')
@section('content')

<div class="container">
        <h2> Completá tus datos</h2>
        <form method="POST" action="{{ route('alumnos.store') }}">
            @csrf
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre</label>
                <input name="nombre" type="text" class="form-control @error('nombre') is-invalid @enderror" id="nombre" aria-describedby="nombre" value="{{old('nombre')}}">
            </div>
            <div class="mb-3">
                <label for="apellido" class="form-label"> Apellido</label>
                <input name="apellido" type="text" class="form-control @error('apellido') is-invalid @enderror" id="apellido" aria-describedby="apellido" value="{{old('apellido')}}">
            </div> 
            <div class="mb-3">
                <label for="dni" class="form-label">DNI</label>
                <input name="dni" type="number" class="form-control @error('dni') is-invalid @enderror" id="dni" aria-describedby="dni" value="{{old('dni')}}" >
            </div>
            
            <button type="submit" class="btn btn-primary">Completar</button>
           
        </form>
    </div>
@endsection