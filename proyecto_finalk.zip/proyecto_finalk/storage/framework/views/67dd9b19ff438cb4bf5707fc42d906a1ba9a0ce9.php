
<?php $__env->startSection('content'); ?>
    <div class=container>
        <h3> Este es el curso de de ingles </h3>
        <p>  </p>
        <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('inscriptos.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                 <input type="hidden" id="nombre_curso" name="nombre_curso" value="ingles">
                <button type="submit" class="btn btn-primary">Sumate al curso</button>
            </form>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary"> Tenes que que estar logueado para sumarte al curso</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto_laravel\proyecto_finalk\resources\views/cursos/ingles.blade.php ENDPATH**/ ?>