<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php if(auth()->guard()->check()): ?>
        <div class="container">
        <h2> Completá tus datos</h2>
        <form method="POST" action="<?php echo e(route('alumnos.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="nombre" class="form-label">Nombre</label>
                    <input name="nombre" type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nombre" aria-describedby="nombre" value="<?php echo e(old('nombre')); ?>">
                </div>
                <div class="mb-3">
                    <label for="apellido" class="form-label"> Apellido</label>
                    <input name="apellido" type="text" class="form-control <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="apellido" aria-describedby="apellido" value="<?php echo e(old('apellido')); ?>">
                </div> 
                <div class="mb-3">
                    <label for="dni" class="form-label">DNI</label>
                    <input name="dni" type="number" class="form-control <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dni" aria-describedby="dni" value="<?php echo e(old('dni')); ?>" >
                </div>
                <button type="submit" class="btn btn-primary">Completar</button>    
        </form>
    </div>        
        <?php else: ?>
        <header>
            <div class="container p-3" >
                <div class="row">
                    <div class="col">
                        <h1>Cursos Online!</h1>
                        <p>Descubre un amplio contenido de formación gratuita para impulsar tu negocio o carrera profesional. Aprende todo lo que necesites seleccionando módulos concretos o, si lo prefieres, haz un curso completo.</p>
                    </div>
                </div>
            </div>
        </header>
        <section>
            <div class="container">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="./img/2.jpg" class="img-fluid" alt="...">
                            <div class="carousel-caption d-none d-md-block">
                                <h5 class="remarca">Carpinteria</h5>
                                <p class="remarca">Te puedes iniciar en la carpintería de toda la vida o también, puedes iniciarte en este curso con "Maderística", y conocer la disciplina que trata sobre el placer de trabajar la madera para hacer muebles con pasión e identidad</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="./img/1_1.jpg" class="img-fluid" alt="...">
                            <div class="carousel-caption d-none d-md-block">
                                <h5 class="remarca">Literatura</h5>
                                <p class="remarca">Curso de literatura 20% off durante todo el verano!</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="./img/3.jpg" class="img-fluid" alt="...">
                            <div class="carousel-caption d-none d-md-block">
                                <h5 class="remarca">Desarrollo Web Full Stack</h5>
                                <p class="remarca">Empeza este 2022 capacitandote en el area de mayor demanda laboral, con los mejores docentes altamente capacitados</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="./img/4.jpg" class="img-fluid" alt="...">
                            <div class="carousel-caption d-none d-md-block">
                                <h5 class="remarca">Curso de ingles</h5>
                                <p class="remarca">Capacitate en aprender y dominar uno de los idiomas mas demandados en el area laboral de forma nacion o internacional</p>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>

            <div class="contCards">
                <h3>Contamos con los mejores docentes de la region</h3>
                <p>Nuestros docentes son de calidad asegurada, cada uno de ellos cuentan con la certificacion alavada por TÜV Rheinland</p>
                <div class="card-group">
                    <div class="card">
                      <img class="card-img-top" src="./img/prof/p1.jpg" alt="Card image cap">
                      <div class="card-body">
                        <h5 class="card-title">Marga Librito</h5>
                        <p class="card-text">Marga Librito es una profesora de ingles actualmente trabaja en la <a href="https://www.uba.ar/">Universidad de Buenos Aires</a>, es docente hace mas 5 años, gano el premio literario inglés. Fue educada en la misma institucion en 1987</p>
                      </div>
                      <div class="card-footer">
                        <small class="text-muted">Última actualización hace 3 minutos</small>
                      </div>
                    </div>
                    <div class="card">
                      <img class="card-img-top" src="./img/prof/p2.jpg" alt="Card image cap">
                      <div class="card-body">
                        <h5 class="card-title">Exequiel Ram</h5>
                        <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
                      </div>
                      <div class="card-footer">
                        <small class="text-muted">Última actualización hace 11 dias</small>
                      </div>
                    </div>
                    <div class="card">
                      <img class="card-img-top" src="./img/prof/p3.jpg" alt="Card image cap">
                      <div class="card-body">
                        <h5 class="card-title">Jesus de Nazaret</h5>
                        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
                      </div>
                      <div class="card-footer">
                        <small class="text-muted">Última actualización hace 13 dias</small>
                      </div>
                    </div>
                    <div class="card">
                        <img class="card-img-top" src="./img/prof/p4.jpg" alt="Card image cap">
                        <div class="card-body">
                          <h5 class="card-title">John Rambo</h5>
                          <p class="card-text">John Rambo es Licenciado en Tecnología Educativa por la Universidad Tecnológica Nacional, Facultad Regional Buenos Aires. Es Master en Animación Audiovisual, titulo de posgrado otorgado por la Universidad Autónoma de Barcelona. Es Profesor en Disciplinas Industriales, título otorgado por el Instituto Superior del Profesorado Técnico dependiente del Rectorado de la Universidad Tecnológica Nacional</p>
                        </div>
                        <div class="card-footer">
                          <small class="text-muted">Última actualización hace 1 mes</small>
                        </div>
                      </div>
                  </div>
            </div>

            
        </section>
        <?php endif; ?>
              
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Xampp\htdocs\proyecto_finalk\resources\views/index.blade.php ENDPATH**/ ?>