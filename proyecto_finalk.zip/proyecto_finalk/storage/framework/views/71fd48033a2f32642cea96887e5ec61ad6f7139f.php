

<?php $__env->startSection('content'); ?>
    <div class=container>
        <header>
            <div class="container p-3" >
                <div class="row">
                    <div class="col">
                        <h3> Este es el curso de programacion </h3>
                        <p> Es un hecho que la tecnología ha cambiado nuestras vidas de manera definitiva y sin vuelta atrás. En la educación se ha convertido en herramienta y en recurso alcanzando un nivel más que aceptable en su uso cotidiano dentro del aula.
                Ahora es la comunidad educativa la que da un paso más y pretende llevar el uso de consumo pasivo de estas herramientas a otro más activo donde el alumno conoce cómo funciona y puede modificar y adaptar su uso para su interés propio.
                La enseñanza de la programación y las ciencias de la computación permiten dotar a los individuos de una metodología de pensamiento y unas herramientas que le facilitarán entender la lógica y funcionamiento de las máquinas y el software que las gobierna. Alcanzar estos niveles de conocimiento supone dotar a los alumnos de capacidades y competencias que en un futuro jugarán (juegan) un papel fundamental en la sociedad. </p>
                    </div>
                </div>
            </div>
        </header>

        <div class="container">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="./img/pr/pr1.jpg" class="img-fluid" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <p class="remarca">Aprende programacion full stack</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="./img/pr/pr2.jpg" class="img-fluid" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <p class="remarca">de 0 a 100, domina los lenguajes de programacion mas demandados en el mercado</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="./img/3.jpg" class="img-fluid" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <p class="remarca">20% off durante el verano!</p>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
                <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('inscriptos.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                 <input type="hidden" id="nombre_curso" name="nombre_curso" value="programacion">
                <button type="submit" class="btn btn-primary">Sumate al curso</button>
            </form>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary"> Tenes que que estar logueado para sumarte al curso</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Xampp\htdocs\proyecto_finalk\resources\views/cursos/programacion.blade.php ENDPATH**/ ?>