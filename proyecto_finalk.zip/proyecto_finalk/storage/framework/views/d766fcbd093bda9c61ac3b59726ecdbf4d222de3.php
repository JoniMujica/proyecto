
<?php $__env->startSection('content'); ?>
    <div class=container>
        <h3> Este es el curso de literatura </h3>
        <p> Las humanidades expresan la experiencia humana a través de varias disciplinas, entre ellas: Historia, Filosofía, Gestión ambiental, Arte, Deporte y Literatura. 

    Ésta área busca aportar herramientas al educando que le permitan desarrollar habilidades para desenvolverse con un sentido más crítico y analítico en su desempeño profesional y personal, desarrollando competencias en todos los ámbitos a través de las experiencias y aprendizajes vividos durante los cursos.

    Su principal fin es sensibilizar al estudiante y lograr que desarrolle todas las funciones humanas de manera integral, abordando no sólo la parte técnica y cognitiva, sino también la ética, afectiva, espiritual y social.

    Por tal motivo, el curso de Literatura nos va a llevar a conocer obras literarias de diferentes escritores, abarcaremos distintas generaciones literarias y recorreremos juntos la historia de la literatura  en las obras de los principales exponentes de la literatura universal.

    Juntos aprenderemos a contextualizar la ideología de una época determinada y a emplear nuestras vivencias y conocimientos en el rescate de nuestros valores y costumbres. Juntos encontraremos más razones por las cuales leer. </p>
        <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('inscriptos.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                 <input type="hidden" id="nombre_curso" name="nombre_curso" value="literatura">
                <button type="submit" class="btn btn-primary">Sumate al curso</button>
            </form>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary"> Tenes que que estar logueado para sumarte al curso</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto_laravel\proyecto_finalk\resources\views/cursos/literatura.blade.php ENDPATH**/ ?>