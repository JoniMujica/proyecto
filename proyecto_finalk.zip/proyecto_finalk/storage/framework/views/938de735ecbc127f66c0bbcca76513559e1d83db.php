
<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->check()): ?>
        <div class="container tpt">
            <table class="table">
                <thead>
                    <tr class="bg-primary">
                        <th scope="col">Curso</th>
                        <th scope="col">Descripción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $inscripciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item): ?>
                            <tr class="table-primary">
                                <td><?php echo e($item->nombre); ?></td>
                                <td><?php echo e($item->descripcion); ?></td>
                                
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <div class="container">
            Debes iniciar sesion para poder ver esta pagina
        </div>
     <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Xampp\htdocs\proyecto_finalk\resources\views/cursos/miscursos.blade.php ENDPATH**/ ?>