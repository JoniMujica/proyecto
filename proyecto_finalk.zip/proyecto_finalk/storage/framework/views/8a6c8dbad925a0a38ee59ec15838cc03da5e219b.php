
<?php $__env->startSection('content'); ?>
    <div class=container>
        <h3> Este es el curso de programacion </h3>
        <p> Es un hecho que la tecnología ha cambiado nuestras vidas de manera definitiva y sin vuelta atrás. En la educación se ha convertido en herramienta y en recurso alcanzando un nivel más que aceptable en su uso cotidiano dentro del aula.
Ahora es la comunidad educativa la que da un paso más y pretende llevar el uso de consumo pasivo de estas herramientas a otro más activo donde el alumno conoce cómo funciona y puede modificar y adaptar su uso para su interés propio.
La enseñanza de la programación y las ciencias de la computación permiten dotar a los individuos de una metodología de pensamiento y unas herramientas que le facilitarán entender la lógica y funcionamiento de las máquinas y el software que las gobierna. Alcanzar estos niveles de conocimiento supone dotar a los alumnos de capacidades y competencias que en un futuro jugarán (juegan) un papel fundamental en la sociedad. </p>
        <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('inscriptos.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                 <input type="hidden" id="nombre_curso" name="nombre_curso" value="programacion">
                <button type="submit" class="btn btn-primary">Sumate al curso</button>
            </form>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary"> Tenes que que estar logueado para sumarte al curso</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto_laravel\proyecto_finalk\resources\views/cursos/programacion.blade.php ENDPATH**/ ?>