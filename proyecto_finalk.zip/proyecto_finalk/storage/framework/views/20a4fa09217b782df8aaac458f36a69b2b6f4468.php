
<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->check()): ?>
        <div class="container">
            Esta es la seccion donde podes ver los cursos en los que te inscribiste
            <?php $__currentLoopData = $inscripciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($curso): ?>
                    <div class="card">
                        <div class="card-header">
                            <?php echo e($curso->nombre); ?>

                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php echo e($curso->descripcion); ?>

                            </p>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>  
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <div class="container">
            Debes iniciar sesion para poder ver esta pagina
        </div>
     <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto_laravel\proyecto_finalk\resources\views/cursos/miscursos.blade.php ENDPATH**/ ?>