<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Plataforma de Cursos')); ?></title>

        <!-- bootstrap -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo e(url('css/app.css')); ?>" type="text/css">
    </head>

    <body >
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="#"> <?php echo e(config('app.name', 'Plataforma de Cursos')); ?></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#">Mis Cursos </a>
                        </li>
                    </ul>
                </div>

                <div class="form-inline my-2 my-lg-0">
                    <?php if(Route::has('login')): ?>
                        <div>
                            <?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(url('/home')); ?>">Home</a>
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit;">Logout</a>
                                <!-- formulario de salida-->
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>"  method="POST" style="display: none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Login</a>
                                <?php if(Route::has('register')): ?>
                                    <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>    
        </nav>
         

      
        <main class="container">
            <?php echo $__env->yieldContent('content'); ?>  
        </main>

        <!-- JS bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js "
        integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB"
        crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-
        QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13"
        crossorigin="anonymous"></script>
        <!-- JS bootstrap -->
    </body>
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <p class="text-center text-sm text-gray-700 dark:text-gray-500">
                        &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name', 'Plataforma de Cursos')); ?>

                    </p>
                </div>
            </div>
        </div>
    </footer>
</html>
<?php /**PATH C:\xampp\htdocs\proyecto_laravel\proyecto_finalk\resources\views/templates/logged.blade.php ENDPATH**/ ?>