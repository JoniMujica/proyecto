
<?php $__env->startSection('content'); ?>

 <?php if(auth()->guard()->check()): ?>
    <div class="top-container dark-background">
        <h2> <?php echo e($titulo); ?> </h2>
        <table class="table">
            <thead>
                <tr class="bg-primary">
                    <th scope="col">Curso</th>
                    <th scope="col">Carga Horaria</th>
                    <th scope="col">Descripción</th>
                    <th scope="col">Docente</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item): ?>
                        <tr class="table-primary">
                            <td><a href="<?php echo e($item->nombre); ?>"><?php echo e($item->nombre); ?></a></td>
                            <td><?php echo e($item->carga_horaria); ?></td>
                            <td><?php echo e($item->descripcion); ?></td>
                            <td><?php echo e($item->docente); ?></td>
                            
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\Xampp\htdocs\proyecto_finalk\resources\views/cursos/cursos.blade.php ENDPATH**/ ?>