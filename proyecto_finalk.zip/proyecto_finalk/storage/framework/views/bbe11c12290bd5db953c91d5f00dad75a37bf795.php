
<?php $__env->startSection('content'); ?>

 <?php if(auth()->guard()->check()): ?>
    <div class="top-container dark-background">
        <h2> <?php echo e($titulo); ?> </h2>
        <table>
            <thead>
                <tr>
                    <th>Curso</th>
                    <th>Carga Horaria</th>
                    <th>Descripción</th>
                    <th>Docente</th>
                    <th>Pagina del curso</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item): ?>
                        <tr>
                            <td><?php echo e($item->nombre); ?></td>
                            <td><?php echo e($item->carga_horaria); ?></td>
                            <td><?php echo e($item->descripcion); ?></td>
                            <td><?php echo e($item->docente); ?></td>
                            <td><a href="<?php echo e($item->nombre); ?>"><?php echo e($item->nombre); ?></a></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto_laravel\proyecto_finalk\resources\views/cursos/cursos.blade.php ENDPATH**/ ?>