<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class InscriptosController extends Controller
{
    public function index()
    {
        $alumno = DB::table('alumno')->latest('id_alumno')->first()->id_alumno;
        $cursos = DB::table('alumnos_cursos')->select('id_CURSO')->where('id_ALUMNO', $alumno)->get();
        foreach( $cursos as $curso ) {
            $inscripciones = DB::table('curso')->select('nombre', 'descripcion')->where('id_CURSO', $curso->id_CURSO)->get();
        } 
        //$inscripciones = DB::table('curso')->select('nombre','descripcion')->find($cursos->id_CURSO);
        $parametros = [
            'inscripciones' => $inscripciones,
        ]; 
        return view('cursos.miscursos', $parametros);
    }
    
    public function store(Request $request)
    {   
        $nombre = $request->input('nombre_curso');
        $id_alumno = DB::table('alumno')->latest('id_alumno')->first()->id_alumno;
        $id_curso = DB::table('curso')->select()->where('nombre', $nombre)->first()->id_curso;
        DB::table('alumnos_cursos')->insert([
            'id_ALUMNO' => $id_alumno,
            'id_CURSO' => $id_curso
        ]);
        return view('miscursos');
    }
}
