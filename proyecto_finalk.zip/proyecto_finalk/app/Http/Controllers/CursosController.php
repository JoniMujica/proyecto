<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class CursosController extends Controller
{
    public function index(Request $request)
    {
        $cursos = DB::table('curso')->select('*')->get();

        $parametros = [
            'cursos' => $cursos,
            'titulo' => 'Cursos Disponibles'
        ];

        return view('cursos.cursos', $parametros);
    }

    public function store(Request $request)
    {
        $nombre = $request->post('nombre');
        $descripcion = $request->post('descripcion');
        $carga = $request->post('carga_horaria');
        $docente = $request->post('docente');

        DB::table('curso')->insert([
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'carga_horaria' => $carga,
            'docente' => $docente
        ]);
        
        return view('welcome');
    }
    

}
