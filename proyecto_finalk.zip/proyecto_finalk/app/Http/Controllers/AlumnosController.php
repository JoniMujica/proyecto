<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AlumnosController extends Controller
{


    public function index()
    {  
        $alumnos= DB::select("SELECT * FROM plataforma_cursos.alumno");
    }
/*
    public function create(array $data){
        return Alumno::create([
        'Nombre' => $data['Nombre'],
        'Apellido' => $data['Apellido'],
        'dni' => $data['dni'],
        ]); 
    } */
    public function store(Request $request)
    {
        $nombre = $request->post('nombre');
        $apellido = $request->post('apellido');
        $dni = $request->post('dni');

        DB::table('alumno')->insert([
            'nombre' => $nombre,
            'apellido' => $apellido,
            'documento' => $dni  
        ]);

        DB::table('alumno_usuario')->insert([
            'id_alumno' => DB::table('alumno')->latest('id_alumno')->first()->id_alumno,
            'id_user' => Auth::id()
        ]);
        return view('welcome');
    }
}
