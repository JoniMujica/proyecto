<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/welcome', function () {
    return view('welcome');
});

Route::get('/literatura', function () {
    return view('cursos.literatura');
});
Route::get('/programacion', function () {
    return view('cursos.programacion');
});
Route::get('/Carpinteria', function () {
    return view('cursos.carpinteria');
});
Route::get('/Ingles', function () {
    return view('cursos.ingles');
});
Route::get('/miscursos', function () {
    return view('cursos.miscursos');
});

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::post('/logout', [App\Http\Controllers\Auth\LoginController::class, 'logout'])->name('logout');



Route::resource('/alumnos', App\Http\Controllers\AlumnosController::class);
Route::resource('/cursos', App\Http\Controllers\CursosController::class);
Route::resource('/inscriptos', App\Http\Controllers\InscriptosController::class);

Route::get('/miscursos', [App\Http\Controllers\InscriptosController::class, 'index']);